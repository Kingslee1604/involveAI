# sample_lambda.py

def lambda_handler(event, context):
    # Your Lambda function logic goes here
    return "Hello from Lambda!"
